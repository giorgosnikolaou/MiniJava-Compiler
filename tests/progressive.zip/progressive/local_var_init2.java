class Main {
    public static void main(String[] args) {
        int a;
        boolean b;
        A c;

    }
  }

class A
{
    int a;
    int b;
    
    public int foo(int a, A b)
    {
        return 1;
    }
} 