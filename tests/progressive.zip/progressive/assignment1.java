class Main {
    public static void main(String[] args) {
        int a;
        boolean b;
        a = 1;
        b = true;
    }
  }