class Main {
    public static void main(String[] args) {
        int a;
        boolean b;

    }
  }