class Main {
    public static void main(String[] args) {
        int a;
        boolean b;
        int[] c;
        boolean[] d;
        A e;

    }
  }

class A
{
    int a;
    int b;
    
    public int foo(int a, A b)
    {
        return 1;
    }
    
    public boolean bar(int[] a, boolean[] b)
    {
        return false;
    }
} 