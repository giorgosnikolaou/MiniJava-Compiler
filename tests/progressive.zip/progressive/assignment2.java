class Main {
    public static void main(String[] args) {
        int a;
        boolean b;
        int[] c;
        boolean[] d;
        A e;
        a = 0-1;
        b = true;
        c = new int[10];
        d = new boolean[11];
        e = new A();
    }
}

class A
{
    
}