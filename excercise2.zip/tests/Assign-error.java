class AssignError {
    public static void main(String[] a){
        int n;
        n = true;
    }
}