class Overload2 {

    public static void main(String[] args){ }

}


class A {

    int x;

    public int x(){
        return 1;
    }

}
