class BadAssign {

    public static void main(String[] args){
        A a;
        B b;
        b = a;
    }

}


class A {

}

class B {

}
