class Overload1 {

    public static void main(String[] args) {}

}


class A {

    public int foo() {
        return 1;
    }

    public int foo(int arg){
        return 1;
    }

}
