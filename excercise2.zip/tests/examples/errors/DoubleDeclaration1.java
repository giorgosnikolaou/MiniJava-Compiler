class DoubleDeclaration1 {

    public static void main(String[] args) {}

}


class A {

    public A foo(A x){

        int x;

        return this;
    }


}
