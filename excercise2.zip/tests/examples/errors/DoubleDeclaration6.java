class DoubleDeclaration6 {

    public static void main(String[] args){

    }

}


class A {

    public int foo(){
        return 1;
    }

    public int foo(){
        return 2;
    }


}
