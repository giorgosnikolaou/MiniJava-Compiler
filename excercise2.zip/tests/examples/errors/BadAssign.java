class BadAssign {

    public static void main(String[] args){
        int i;
        A a;
        a = i;
    }

}


class A {

}
